main :: IO ()
main = do
    contents <- readFile "ciphertext"
    let list = [ [ c | c <- line, c `elem` ['0'..'9']] | line <- lines contents ]
    let nums = [ read x :: Integer | x <- list]
    let c = last nums :: Integer
    print integerCubeRoot c
